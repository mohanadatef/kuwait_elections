<?php $__env->startSection('title'); ?>
   قائمه عن الشركه
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head_style'); ?>
    <?php echo $__env->make('includes.admin.header_datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
         عن الشركه
            <small>كل عن الشركه</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i>لوحه التحكم</a></li>
            <li><a href="<?php echo e(url('/admin/about_us/index')); ?>"><i class="fa fa-permissions"></i>عن الشركه</a></li>
        </ol>
    </section>
    <section class="content">
            <div class="box">
                <div class="box-header" align="right">
                    <?php if (\Entrust::can('about-us-create')) : ?>
                    <?php if($datas->count() == 0): ?>
                    <a href="<?php echo e(url('/admin/about_us/create')); ?>" class="btn btn-primary">اضافه</a>
                    <?php endif; ?>
                    <?php endif; // Entrust::can ?>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <?php if(count($datas) > 0): ?>
                        <div align="center" class="col-md-12 table-responsive">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                <tr>
                                    <th align="center">العنوان</th>
                                    <th align="center">الوصف</th>
                                    <th align="center">صوره</th>
                                    <th align="center">تحكم</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td align="center"><?php echo e($data->title); ?></td>
                                        <td align="center"><?php echo $data->description; ?></td>
                                        <td align="center"><img src="<?php echo e(asset('public/images/about_us/' . $data->image )); ?>" style="width:100px;height: 100px"></td>
                                        <td align="center">
                                            <?php if (\Entrust::can('about-us-edit')) : ?>
                                            <a href="<?php echo e(url('/admin/about_us/edit/'.$data->id)); ?>"><i class="btn btn-sm btn-primary ace-icon fa fa-edit bigger-120  edit" data-id=""> Edit</i></a>
                                            <?php endif; // Entrust::can ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th align="center">العنوان</th>
                                    <th align="center">الوصف</th>
                                    <th align="center">صوره</th>
                                    <th align="center">تحكم</th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    <?php else: ?>
                        <div align="center">لا يوجد بيانات لعرضها</div>
                    <?php endif; ?>
                </div>
                <!-- /.box-body -->
            </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_style'); ?>
    <?php echo $__env->make('includes.admin.scripts_datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuwait_elections\resources\views/admin/setting/about_us/index.blade.php ENDPATH**/ ?>