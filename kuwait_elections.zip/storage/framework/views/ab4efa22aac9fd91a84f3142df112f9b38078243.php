<?php $__env->startSection('title'); ?>
   تعديل اتصل بنا
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            اتصل بنا
            <small>تعديل اتصل بنا</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i>لوحه التحكم</a></li>
            <li><a href="<?php echo e(url('/admin/contact_us/index')); ?>"><i class="fa fa-permsissions"></i>اتصل بنا</a></li>
            <li><a href="<?php echo e(url('/admin/contact_us/edit/'.$data->id)); ?>"><i class="fa fa-permsission"></i>تعديل اتصل بنا: <?php echo e($data->title); ?> </a></li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <div class="box-header">
                <h3>تعديل اتصل بنا: <?php echo e($data->title); ?> </h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <form id="edit" action="<?php echo e(url('admin/contact_us/update/'.$data->id)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('patch')); ?>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ""); ?>">
                                البريد الالكتروني : <input type="email" class="form-control" name="email" value="<?php echo e($data->email); ?>"
                                               placeholder="برجاء ادخال البريد الالكتروني">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ""); ?>">
                                الهاتف : <input type="text" value="<?php echo e($data->phone); ?>"
                                               class="form-control" name="phone" placeholder="برجاء ادخال الهاتف">
                            </div>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ""); ?>">
                        العنوان : <input type="text" value="<?php echo e($data->address); ?>"
                                         class="form-control" name="address" placeholder="برجاء ادخال العنوان">
                    </div>


                    <div class="form-group<?php echo e($errors->has('time_work') ? ' has-error' : ""); ?>">
                        اوقات العمل : <input type="text" value="<?php echo e($data->time_work); ?>"
                                           class="form-control" name="time_work" placeholder="برجاء ادخال اوقات العمل">
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group<?php echo e($errors->has('latitude') ? ' has-error' : ""); ?>">
                                خط العرض : <input type="text" value="<?php echo e($data->latitude); ?>"
                                                  class="form-control" name="latitude" placeholder="برجاء ادخال خط العرض">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group<?php echo e($errors->has('longitude') ? ' has-error' : ""); ?>">
                                خط الطول : <input type="text" value="<?php echo e($data->longitude); ?>"
                                                   class="form-control" name="longitude"
                                                   placeholder="برجاء ادخال خط الطول">
                            </div>
                        </div>
                    </div>
                    <div align="center">
                        <input type="submit" class="btn btn-primary" value="تعديل">
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_style'); ?>
    <?php echo JsValidator::formRequest('App\Http\Requests\Admin\Setting\Contact_Us\EditRequest','#edit'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuwait_elections\resources\views/admin/setting/contact_us/edit.blade.php ENDPATH**/ ?>