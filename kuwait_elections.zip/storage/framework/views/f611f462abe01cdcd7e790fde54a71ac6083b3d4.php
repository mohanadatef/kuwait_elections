<?php $__env->startSection('title'); ?>
    اضافه مستخدم
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head_style'); ?>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/css/admin/multi-select.css')); ?>">
    <style>
        .ms-container {
            width: 25%;
        }
        li.ms-elem-selectable, .ms-selected {
            padding: 5px !important;
        }
        .ms-list {
            height: 150px !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            قائمه المستخدمين
            <small>اضافه المستخدم</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> لوحه التحكم</a></li>
            <li><a href="<?php echo e(url('/admin/user/index')); ?>"><i class="fa fa-users"></i>قائمه المستخدمين</a></li>
            <li><a href="<?php echo e(url('/admin/user/create')); ?>"><i class="fa fa-user"></i>اضافه مستخدم</a></li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <div class="box-header">
                <h3>اضافه مستخدم</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <form id="user_create" action="<?php echo e(url('admin/user/store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ""); ?>">
                        civil_reference : <input type="text" value="<?php echo e(Request::old('civil_reference')); ?>" class="form-control"
                                             name="civil_reference"
                                             placeholder="برجاء ادخال رقم الهاتف">
                    </div>
                    <div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ""); ?>">
                        الاسم الاول : <input type="text" value="<?php echo e(Request::old('first_name')); ?>" class="form-control"
                                            name="first_name"
                                            placeholder="برجاء ادخال رقم الهاتف">
                    </div>
                    <div class="form-group<?php echo e($errors->has('second_name') ? ' has-error' : ""); ?>">
                        اسم second_name : <input type="text" value="<?php echo e(Request::old('second_name')); ?>" class="form-control"
                                            name="second_name"
                                            placeholder="برجاء ادخال رقم الهاتف">
                    </div>
                    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ""); ?>">
                        رقم name : <input type="text" value="<?php echo e(Request::old('name')); ?>" class="form-control"
                                           name="name"
                                           placeholder="برجاء ادخال رقم الهاتف">
                    </div>
                    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ""); ?>">
                        كلمه السر : <input type="password" value="<?php echo e(Request::old('password')); ?>" class="form-control"
                                          name="password" placeholder="برجاء ادخال كلمه السر">
                    </div>
                    <div class="form-group">
                        تاكيد كلمه السر : <input type="password" value="<?php echo e(Request::old('password')); ?>"
                                                       class="form-control" name="password_confirmation"
                                                       placeholder="برجاء تاكيد كلمه السر">
                    </div>
                    <div class="form-group<?php echo e($errors->has('circle_id') ? ' has-error' : ""); ?>">
                        اختار الدائرة :
                        <select id="circle" class="form-control select2" data-placeholder="برجاء اختيار الدائرة" name="circle_id">
                            <option value="0" selected>اختار الدائرة</option>
                            <?php $__currentLoopData = $circle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mycircle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($mycircle->id); ?>"> <?php echo e($mycircle->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group<?php echo e($errors->has('area_id') ? ' has-error' : ""); ?>">
                        اختار المنطقه : <select id="area" class="form-control select2" data-placeholder="برجاء اختيار المنطقه" name="area_id">
                            <?php $__currentLoopData = $area; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($myarea->id); ?>"> <?php echo e($myarea->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group<?php echo e($errors->has('role_id') ? ' has-error' : ""); ?>">
                        اختار نوع المستخدم :
                        <select id="role" multiple='multiple' class="form-control"  name="role_id[]">
                            <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myrole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($myrole->id); ?>"> <?php echo e($myrole->display_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div align="center">
                        <input type="submit" class="btn btn-primary" value="اضافه">
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_style'); ?>
    <script src="<?php echo e(url('public/js/admin/jquery.multi-select.js')); ?>"></script>
    <script type="text/javascript">
        $('#role').multiSelect();
    </script>
    <?php echo JsValidator::formRequest('App\Http\Requests\Admin\ACL\User\CreateRequest','#create'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuwait_elections\resources\views/admin/acl/user/create.blade.php ENDPATH**/ ?>