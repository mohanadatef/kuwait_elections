<?php $__env->startSection('title'); ?>
    تعديل المستخدم
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head_style'); ?>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/css/admin/multi-select.css')); ?>">
    <style>
        .ms-container {
            width: 25%;
        }
        li.ms-elem-selectable, .ms-selected {
            padding: 5px !important;
        }
        .ms-list {
            height: 150px !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            المستخدمين
            <small>تعديل المستخدم</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> لوحه التحكم</a></li>
            <li><a href="<?php echo e(url('/admin/user/index')); ?>"><i class="fa fa-users"></i>قائمه المستخدم</a></li>
            <li><a href="<?php echo e(url('/admin/user/edit/'.$data->id)); ?>"><i class="fa fa-user"></i>تعديل المستخدم : <?php echo e($data->username); ?></a></li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <div class="box-header">
                <h3>تعديل المستخدم  : <?php echo e($data->username); ?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <form id="edit" action="<?php echo e(url('admin/user/update/'.$data->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('patch')); ?>

                    <div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ""); ?>">
                        الاسم كامل : <input type="text" value="<?php echo e($data->name); ?>" class="form-control"
                                            name="name"
                                            placeholder="برجاء ادخال الاسم كامل">
                    </div>
                    <div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ""); ?>">
                        الاسم الاول : <input type="text" value="<?php echo e($data->first_name); ?>" class="form-control"
                                             name="first_name"
                                             placeholder="برجاء ادخال الاول">
                    </div>
                    <div class="form-group<?php echo e($errors->has('second_name') ? ' has-error' : ""); ?>">
                        اسم الثاني : <input type="text" value="<?php echo e($data->second_name); ?>" class="form-control"
                                            name="second_name"
                                            placeholder="برجاء ادخال اسم الثاني">
                    </div>
                    <div class="form-group<?php echo e($errors->has('third_name') ? ' has-error' : ""); ?>">
                        الاسم الثالث : <input type="text" value="<?php echo e($data->third_name); ?>" class="form-control"
                                              name="third_name"
                                              placeholder="برجاء ادخال الثالث">
                    </div>
                    <div class="form-group<?php echo e($errors->has('forth_name') ? ' has-error' : ""); ?>">
                        اسم الرابع : <input type="text" value="<?php echo e($data->forth_name); ?>" class="form-control"
                                            name="forth_name"
                                            placeholder="برجاء ادخال اسم الرابع">
                    </div>
                    <div class="form-group<?php echo e($errors->has('internal_reference') ? ' has-error' : ""); ?>">
                        المرجع الداخلي : <input type="text" value="<?php echo e($data->internal_reference); ?>" class="form-control"
                                                name="internal_reference"
                                                placeholder="برجاء ادخال المرجع الداخلي">
                    </div>
                    <div class="form-group<?php echo e($errors->has('civil_reference') ? ' has-error' : ""); ?>">
                        المرجع المدني : <input type="text" value="<?php echo e($data->civil_reference); ?>" class="form-control"
                                               name="civil_reference"
                                               placeholder="برجاء ادخال المرجع المدني">
                    </div>
                    <div class="form-group<?php echo e($errors->has('job') ? ' has-error' : ""); ?>">
                        مهنة : <input type="text" value="<?php echo e($data->job); ?>" class="form-control"
                                      name="job"
                                      placeholder="برجاء ادخال مهنة">
                    </div>
                    <div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ""); ?>">
                        عنوان : <input type="text" value="<?php echo e($data->address); ?>" class="form-control"
                                       name="address"
                                       placeholder="برجاء ادخال عنوان">
                    </div>
                    <div class="form-group<?php echo e($errors->has('registration_status') ? ' has-error' : ""); ?>">
                        حالة التسجيل : <input type="text" value="<?php echo e($data->registration_status); ?>" class="form-control"
                                              name="registration_status"
                                              placeholder="برجاء ادخال حالة التسجيل">
                    </div>
                    <div class="form-group<?php echo e($errors->has('registration_number') ? ' has-error' : ""); ?>">
                        رقم التسجيل : <input type="text" value="<?php echo e($data->registration_number); ?>" class="form-control"
                                             name="registration_number"
                                             placeholder="برجاء ادخال رقم التسجيل">
                    </div>
                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ""); ?>">
                        البريد الإلكتروني : <input type="email" value="<?php echo e($data->email); ?>" class="form-control"
                                                   name="email"
                                                   placeholder="برجاء ادخال البريد الإلكتروني">
                    </div>
                    <div class="form-group<?php echo e($errors->has('mobile') ? ' has-error' : ""); ?>">
                        التليفون المحمول : <input type="text" value="<?php echo e($data->mobile); ?>" class="form-control"
                                                  name="mobile"
                                                  placeholder="برجاء ادخال التليفون المحمول">
                    </div>
                    <div class="form-group<?php echo e($errors->has('about') ? ' has-error' : ""); ?>">
                        الحمله الانتخابيه : <input type="text" value="<?php echo e($data->about); ?>" class="form-control"
                                                   name="about"
                                                   placeholder="برجاء ادخال الحمله الانتخابيه">
                    </div>
                    <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ""); ?>">
                        <table class="table">
                            <tr>
                                <td width="40%" align="right"><label>برجاء تحميل صوره</label></td>
                                <td width="30"><input type="file" value="<?php echo e(Request::old('image')); ?>" name="image"/></td>
                            </tr>
                            <tr>
                                <td width="40%" align="right"></td>
                                <td width="30"><span class="text-muted">jpg, png, gif</span></td>
                            </tr>
                        </table>
                    </div>
                    <div class="form-group<?php echo e($errors->has('circle_id') ? ' has-error' : ""); ?>">
                        اختار الدائرة :
                        <select id="circle" class="form-control" data-placeholder="برجاء اختار الدائرة" name="circle_id">
                            <option value="0" selected>اختار الدائرة</option>
                            <?php $__currentLoopData = $circle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mycircle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($mycircle->id); ?>" <?php if($mycircle->id == $data->circle_id): ?>selected <?php endif; ?> > <?php echo e($mycircle->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group<?php echo e($errors->has('area_id') ? ' has-error' : ""); ?>">
                        اختار المنطقه : <select id="area" class="form-control" data-placeholder=" برجاء اختار المنطقه " name="area_id">
                            <?php $__currentLoopData = $area; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($myarea->id); ?>" <?php if($myarea->id == $data->area_id): ?>selected <?php endif; ?> > <?php echo e($myarea->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group<?php echo e($errors->has('role_id') ? ' has-error' : ""); ?>">
                        اختار نوع المستخدم :
                        <select id="role" multiple='multiple' class="form-control"  name="role_id[]">
                            <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myrole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($myrole->id); ?>"
                                        <?php $__currentLoopData = $role_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myrole_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($myrole_user->role_id ==$myrole->id): ?>){
                                        selected } <?php else: ?>{ }<?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> > <?php echo e($myrole->display_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div align="center">
                        <input type="submit" class="btn btn-primary" value="تعديل">
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_style'); ?>
    <script src="<?php echo e(url('public/js/admin/jquery.multi-select.js')); ?>"></script>
    <script type="text/javascript">
        $('#role').multiSelect();
    </script>
    <?php echo JsValidator::formRequest('App\Http\Requests\Admin\ACL\User\EditRequest','#edit'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuwait_elections\resources\views/admin/acl/user/edit.blade.php ENDPATH**/ ?>