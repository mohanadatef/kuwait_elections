<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Left side column. contains the logo and sidebar -->
        <ul class="sidebar-menu" data-widget="tree">
            <?php if (\Entrust::can('setting-list')) : ?>
            <li class="treeview">
                <a href="#"><i class="fa fa-group"></i> <span>الأعدادات</span><span class="pull-right-container"><i
                                class="fa fa-angle-right pull-left"></i></span></a>
                <ul class="treeview-menu">
                    <?php if (\Entrust::can('setting-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>الأعدادات</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('setting-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/setting/index')); ?>"><i
                                            class="fa fa-group"></i><span>قائمة الأعدادات</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('about-us-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>عن الشركة</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('about-us-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/about_us/index')); ?>"><i
                                            class="fa fa-group"></i><span>عن الشركة</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('privacy-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>الشروط و الاحكام</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('privacy-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/privacy/index')); ?>"><i
                                            class="fa fa-group"></i><span>الشروط و الاحكام</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('contact-us-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>اتصل بنا</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('contact-us-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/contact_us/index')); ?>"><i class="fa fa-group"></i><span>اتصل بنا</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('call-us-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>تواصل معانا</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('call-us-read')) : ?>
                            <li><a href="<?php echo e(url('/admin/call_us/read')); ?>"><i class="fa fa-group"></i><span>اتصل بنا المقرؤه</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('call-us-unread')) : ?>
                            <li><a href="<?php echo e(url('/admin/call_us/unread')); ?>"><i class="fa fa-group"></i><span>اتصل بنا غير المقرؤه</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                </ul>
            </li>
            <?php endif; // Entrust::can ?>
            <?php if (\Entrust::can('acl-list')) : ?>
            <li class="treeview">
                <a href="#"><i class="fa fa-group"></i> <span>الامان</span><span class="pull-right-container"><i
                                class="fa fa-angle-right pull-left"></i></span></a>
                <ul class="treeview-menu">
                    <?php if (\Entrust::can('user-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>المستخدمين</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('user-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/user/index')); ?>"><i
                                            class="fa fa-group"></i><span>قائمة المستخدمين</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('user-create')) : ?>
                            <li><a href="<?php echo e(url('/admin/user/create')); ?>"><i
                                            class="fa fa-group"></i><span>اضافة مستخدم</span></a></li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('role-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>نوع المستخدم</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('role-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/role/index')); ?>"><i
                                            class="fa fa-group"></i><span>قائمة انواع المستخدم</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('role-create')) : ?>
                            <li><a href="<?php echo e(url('/admin/role/create')); ?>"><i
                                            class="fa fa-group"></i><span>اضافه نوع مستخدم</span></a></li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('permission-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>اذنات</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('permission-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/permission/index')); ?>"><i class="fa fa-group"></i><span>قائمه الاذنات</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('friend-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>الصداقه</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('friend-request')) : ?>
                            <li><a href="<?php echo e(url('/admin/friend/request')); ?>"><i class="fa fa-group"></i><span>قائمه طلبات الصداقه</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('friend-friend')) : ?>
                            <li><a href="<?php echo e(url('/admin/friend/')); ?>"><i class="fa fa-group"></i><span>قائمه الاصدقاء</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('log-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>السجل</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('log-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/log/index')); ?>"><i class="fa fa-group"></i><span>قائمه السجل</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('takeed-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>الناخبين</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('takeed-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/takeed/index')); ?>"><i
                                            class="fa fa-group"></i><span>قائمه رفع الناخبين</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                </ul>
            </li>
            <?php endif; // Entrust::can ?>
            <?php if (\Entrust::can('core-data-list')) : ?>
            <li class="treeview">
                <a href="#"><i class="fa fa-group"></i> <span>بيانات الموقع</span><span class="pull-right-container"><i
                                class="fa fa-angle-right pull-left"></i></span></a>
                <ul class="treeview-menu">
                    <?php if (\Entrust::can('circle-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>الدوائر</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('circle-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/circle/index')); ?>"><i
                                            class="fa fa-group"></i><span>قائمه الدوائر</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('circle-create')) : ?>
                            <li><a href="<?php echo e(url('/admin/circle/create')); ?>"><i
                                            class="fa fa-group"></i><span>اضافه الدائره</span></a></li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('area-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>المناطق</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('area-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/area/index')); ?>"><i
                                            class="fa fa-group"></i><span>قائمه المناطق</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('area-create')) : ?>
                            <li><a href="<?php echo e(url('/admin/area/create')); ?>"><i
                                            class="fa fa-group"></i><span>اضافه منطقه</span></a></li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                </ul>
            </li>
            <?php endif; // Entrust::can ?>
            <?php if (\Entrust::can('social-media-list')) : ?>
            <li class="treeview">
                <a href="#"><i class="fa fa-group"></i> <span>سوشيال ميديا</span><span class="pull-right-container"><i
                                class="fa fa-angle-right pull-left"></i></span></a>
                <ul class="treeview-menu">
                    <?php if (\Entrust::can('post-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>المنشورات</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('post-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/post/index')); ?>"><i
                                            class="fa fa-group"></i><span>قائمه المنشورات</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('commit-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>التعليقات</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('commit-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/commit/index')); ?>"><i
                                            class="fa fa-group"></i><span>قائمه التعليقات</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('like-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>الاعجابات</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('commit-index')) : ?>
                            <li><a href="<?php echo e(url('/admin/like/index')); ?>"><i
                                            class="fa fa-group"></i><span>قائمه الاعجابات</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                </ul>
            </li>
            <?php endif; // Entrust::can ?>
            <?php if (\Entrust::can('import-list')) : ?>
            <li class="treeview">
                <a href="#"><i class="fa fa-group"></i> <span>الرفع</span><span class="pull-right-container"><i
                                class="fa fa-angle-right pull-left"></i></span></a>
                <ul class="treeview-menu">
                    <?php if (\Entrust::can('takeed-list')) : ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-circle-o"></i> <span>الناخبين</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-left"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if (\Entrust::can('takeed-form-import')) : ?>
                            <li><a href="<?php echo e(url('/admin/takeed/import/form')); ?>"><i
                                            class="fa fa-group"></i><span> رفع الناخبين</span></a>
                            </li>
                            <?php endif; // Entrust::can ?>
                        </ul>
                    </li>
                    <?php endif; // Entrust::can ?>
                </ul>
            </li>
            <?php endif; // Entrust::can ?>
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>
<?php echo $__env->yieldContent('main-sidebar'); ?>
<?php /**PATH C:\xampp\htdocs\kuwait_elections\resources\views/includes/admin/main-sidebar.blade.php ENDPATH**/ ?>