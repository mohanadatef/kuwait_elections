<?php $__env->startSection('title'); ?>
    قائمه المناطق
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head_style'); ?>
    <?php echo $__env->make('includes.admin.header_datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            المناطق
            <small>كل المناطق</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> لوحه التحكم</a></li>
            <li><a href="<?php echo e(url('/admin/area/index')); ?>"><i class="fa fa-areas"></i> قائمه المناطق</a></li>
        </ol>
    </section>
    <section class="content">
        <form method="get" action="<?php echo e(url('/admin/area/change_many_status')); ?>">
            <div class="box">
                <div class="box-header" align="right">
                    <?php if (\Entrust::can('area-create')) : ?>
                    <a href="<?php echo e(url('/admin/area/create')); ?>" class="btn btn-primary">اضافه</a>
                    <?php endif; // Entrust::can ?>
                    <?php if (\Entrust::can('area-many-status')) : ?>
                    <input type="submit" value="تغير الحاله" class="btn btn-primary">
                    <?php endif; // Entrust::can ?>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <?php if(count($datas) > 0): ?>
                        <div align="center" class="col-md-12 table-responsive">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                <tr>
                                    <?php if (\Entrust::can('area-many-status')) : ?>
                                    <th align="center">#</th>
                                    <?php endif; // Entrust::can ?>
                                    <th align="center">الاسم</th>
                                    <?php if (\Entrust::can('area-status')) : ?>
                                    <th align="center">الحاله</th>
                                    <?php endif; // Entrust::can ?>
                                    <?php if (\Entrust::can('area-edit')) : ?>
                                    <th align="center">التحكم</th>
                                    <?php endif; // Entrust::can ?>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td align="center">
                                                    <input type="checkbox" name="change_status[]" id="<?php echo e($data->id); ?>" value="<?php echo e($data->id); ?>">
                                        </td>
                                        <td align="center"><?php echo e($data->title); ?></td>
                                        <?php if (\Entrust::can('area-status')) : ?>
                                        <td align="center">
                                                <?php if($data->status ==1): ?>
                                                    <a href="<?php echo e(url('/admin/area/change_status/'.$data->id)); ?>"><i
                                                                class="btn btn-danger ace-icon fa fa-close"> غير مفعل</i></a>
                                                <?php elseif($data->status ==0): ?>
                                                    <a href="<?php echo e(url('/admin/area/change_status/'.$data->id)); ?>"><i
                                                                class="btn btn-primary ace-icon fa fa-check-circle"> مفعل</i></a>
                                                <?php endif; ?>
                                        </td>
                                        <?php endif; // Entrust::can ?>
                                        <?php if (\Entrust::can('area-edit')) : ?>
                                        <td align="center">
                                                <a href="<?php echo e(url('/admin/area/edit/'.$data->id)); ?>"><i
                                                            class="btn btn-primary ace-icon fa fa-edit bigger-120  edit"
                                                            data-id=""> تعديل</i></a>
                                        </td>
                                        <?php endif; // Entrust::can ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <?php if (\Entrust::can('area-many-status')) : ?>
                                    <th align="center">#</th>
                                    <?php endif; // Entrust::can ?>
                                    <th align="center">الاسم</th>
                                    <?php if (\Entrust::can('area-status')) : ?>
                                    <th align="center">الحاله</th>
                                    <?php endif; // Entrust::can ?>
                                    <?php if (\Entrust::can('area-edit')) : ?>
                                    <th align="center">التحكم</th>
                                    <?php endif; // Entrust::can ?>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    <?php else: ?>
                        <div align="center">لا يوجد بيانات للعرض</div>
                    <?php endif; ?>
                </div>
                <!-- /.box-body -->
            </div>
        </form>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_style'); ?>
    <?php echo $__env->make('includes.admin.scripts_datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo JsValidator::formRequest('App\Http\Requests\Admin\Core_Data\Area\StatusEditRequest','#status'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuwait_elections\resources\views/admin/core_data/area/index.blade.php ENDPATH**/ ?>