<?php $__env->startSection('title'); ?>
    قائمه المنشورات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head_style'); ?>
    <?php echo $__env->make('includes.admin.header_datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            المنشورات
            <small>كل المنشورات</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> لوحه التحكم</a></li>
            <li><a href="<?php echo e(url('/admin/post/index')); ?>"><i class="fa fa-users"></i>قائمه المنشورات</a></li>
        </ol>
    </section>
    <section class="content">
        <form method="get" id="status" action="<?php echo e(url('/admin/post/change_many_status')); ?>">
        <div class="box">
            <div class="box-header" align="right">
                <?php if (\Entrust::can('post-many-status')) : ?>
                <input type="submit" value="تغير الحاله" class="btn btn-primary">
                <?php endif; // Entrust::can ?>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <?php if(count($datas) > 0): ?>
                    <div align="center" class="col-md-12 table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <?php if (\Entrust::can('post-many-status')) : ?>
                        <th align="center">#</th>
                        <?php endif; // Entrust::can ?>
                        <th align="center">تاريخ / الوقت</th>
                        <th align="center">المنشور</th>
                        <th align="center">الحاله</th>
                        <th align="center">اسم المستخدم</th>
                        <th align="center">اعجاب</th>
                        <th align="center">تعليق</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php if (\Entrust::can('post-many-status')) : ?>
                            <td align="center">
                                <input type="checkbox" name="change_status[]" id="<?php echo e($data->id); ?>" value="<?php echo e($data->id); ?>">
                            </td>
                            <?php endif; // Entrust::can ?>
                            <td align="center"><?php echo e($data->created_at); ?></td>
                            <td align="center"><?php echo e($data->details); ?></td>

                            <?php if (\Entrust::can('post-status')) : ?>
                            <td align="center">
                                <?php if($data->status ==1): ?>
                                    <a href="<?php echo e(url('/admin/post/change_status/'.$data->id)); ?>"><i
                                                class="btn btn-danger ace-icon fa fa-close"> غير مفعل</i></a>
                                <?php elseif($data->status ==0): ?>
                                    <a href="<?php echo e(url('/admin/post/change_status/'.$data->id)); ?>"><i
                                                class="btn btn-primary ace-icon fa fa-check-circle"> مفعل</i></a>
                                <?php endif; ?>
                            </td>
                            <?php endif; // Entrust::can ?>
                            <td align="center"><?php echo e($data->user->username); ?></td>
                            <td align="center"><?php echo e(count($data->like)); ?> <br> <?php if(count($data->like)> 0): ?> <?php if (\Entrust::can('like-index')) : ?> <a href="<?php echo e(url('/admin/like/index/'.$data->id.'/post')); ?>"><i
                                            class="btn btn-primary"> عرض الاعجابات</i></a> <?php endif; // Entrust::can ?> <?php endif; ?></td>
                            <td align="center"><?php echo e(count($data->commit_post)); ?> <br> <?php if(count($data->commit_post)> 0): ?> <?php if (\Entrust::can('commit-post-index')) : ?> <a href="<?php echo e(url('/admin/commit/post/index/'.$data->id)); ?>"><i
                                            class="btn btn-primary"> عرض التعليقات</i></a> <?php endif; // Entrust::can ?> <?php endif; ?> </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                    <tr>
                        <?php if (\Entrust::can('post-many-status')) : ?>
                        <th align="center">#</th>
                        <?php endif; // Entrust::can ?>
                        <th align="center">تاريخ / الوقت</th>
                        <th align="center">المنشور</th>
                        <?php if (\Entrust::can('post-status')) : ?>
                        <th align="center">الحاله</th>
                        <?php endif; // Entrust::can ?>
                        <th align="center">اسم المستخدم</th>
                        <th align="center">اعجاب</th>
                        <th align="center">تعليق</th>
                    </tr>
                    </tfoot>
                </table>
                    </div>
                <?php else: ?>
                    <div align="center">لا يوجد بيانات لعرضها</div>
                <?php endif; ?>
            </div>
            <!-- /.box-body -->
        </div>
        </form>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_style'); ?>
    <?php echo $__env->make('includes.admin.scripts_datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo JsValidator::formRequest('App\Http\Requests\Admin\Social_Media\Post\StatusEditRequest','#status'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuwait_elections\resources\views/admin/social_media/post/index.blade.php ENDPATH**/ ?>