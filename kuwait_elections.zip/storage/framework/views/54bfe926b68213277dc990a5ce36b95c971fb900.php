<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>نسخه</b> 1.0.0
    </div>
    <strong>حقوق النشر &copy; 2020 <a href="#"> </a>.</strong> كلها محفوظه .
</footer>
<?php echo $__env->yieldContent('footer'); ?><?php /**PATH C:\xampp\htdocs\kuwait_elections\resources\views/includes/admin/footer.blade.php ENDPATH**/ ?>