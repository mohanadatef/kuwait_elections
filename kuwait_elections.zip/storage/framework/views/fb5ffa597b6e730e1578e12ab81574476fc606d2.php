<?php $__env->startSection('title'); ?>
    تعديل الاعددات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            الاعدادت
            <small>تعديل الاعدادت</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i>لوحه التحكم</a></li>
            <li><a href="<?php echo e(url('/admin/setting/index')); ?>"><i class="fa fa-permsissions"></i>الاعدادت</a></li>
            <li><a href="<?php echo e(url('/admin/setting/edit/'.$data->id)); ?>"><i class="fa fa-permsission"></i>تعديل الاعدادت: <?php echo e($data->title); ?> </a></li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <div class="box-header">
                <h3>تعديل الاعدادات: <?php echo e($data->title); ?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <form id="edit" action="<?php echo e(url('admin/setting/update/'.$data->id)); ?>"
                      enctype="multipart/form-data" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('patch')); ?>


                            <div class="form-group<?php echo e($errors->has('title_ar') ? ' has-error' : ""); ?>">
                                الاسم : <input type="text" id="title" value="<?php echo e($data->title); ?>"
                                                      class="form-control" name="title"
                                                      placeholder="برجاء ادخال الاسم">
                            </div>

                    <div class="form-group<?php echo e($errors->has('facebook') ? ' has-error' : ""); ?>">
                        الفيس بوك : <input type="text" value="<?php echo e($data->facebook); ?>" class="form-control" name="facebook"
                                          placeholder="برجاء ادخال الفيس بوك">
                    </div>
                    <div class="form-group<?php echo e($errors->has('youtube') ? ' has-error' : ""); ?>">
                        اليوتيوب : <input type="text" value="<?php echo e($data->youtube); ?>" class="form-control" name="youtube"
                                         placeholder="برجاء ادخال اليوتيوب">
                    </div>
                    <div class="form-group<?php echo e($errors->has('twitter') ? ' has-error' : ""); ?>">
                        تويتر : <input type="text" value="<?php echo e($data->twitter); ?>" class="form-control" name="twitter"
                                         placeholder="برجاء ادخال تويتر">
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <img src="<?php echo e(url('public/images/setting').'/'.$data->image); ?>" style="width:100px;height: 100px">
                            <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ""); ?>">
                                <table class="table">
                                    <tr>
                                        <td width="40%" align="right"><label>برجاء تحميل صوره الموقع</label></td>
                                        <td width="30"><input type="file" value="<?php echo e(Request::old('image')); ?>"
                                                              name="image"/></td>
                                    </tr>
                                    <tr>
                                        <td width="40%" align="right"></td>
                                        <td width="30"><span class="text-muted">jpg, png, gif</span></td>
                                    </tr>
                                </table>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <img src="<?php echo e(url('public/images/setting').'/'.$data->logo); ?>" style="width:100px;height: 100px">
                            <div class="form-group<?php echo e($errors->has('logo') ? ' has-error' : ""); ?>">
                                <table class="table">
                                    <tr>
                                        <td width="40%" align="right"><label>برجاء ادخال الشعار الموقع</label></td>
                                        <td width="30"><input type="file" value="<?php echo e(Request::old('logo')); ?>" name="logo"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td width="40%" align="right"></td>
                                        <td width="30"><span class="text-muted">jpg, png, gif</span></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div align="center">
                        <input type="submit" class="btn btn-primary" value="تعديل">
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_style'); ?>
    <?php echo JsValidator::formRequest('App\Http\Requests\Admin\Setting\Setting\EditRequest','#edit'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuwait_elections\resources\views/admin/setting/setting/edit.blade.php ENDPATH**/ ?>