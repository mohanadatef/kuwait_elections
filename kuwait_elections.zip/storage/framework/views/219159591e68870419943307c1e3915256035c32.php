<?php $__env->startSection('title'); ?>
    قائمه الناخبين
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head_style'); ?>
    <?php echo $__env->make('includes.admin.header_datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            الناخبين
            <small>كل الناخبين</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> لوحه التحكم</a></li>
            <li><a href="<?php echo e(url('/admin/takeed/index')); ?>"><i class="fa fa-areas"></i> قائمه الناخبين</a></li>
        </ol>
    </section>
    <section class="content">
            <div class="box">
                <div class="box-header" align="right">
                    <?php if (\Entrust::can('takeed-form-import')) : ?>
                    <a href="<?php echo e(url('/admin/takeed/import/form')); ?>" class="btn btn-primary">رفع</a>
                    <?php endif; // Entrust::can ?>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <?php if(count($datas) > 0): ?>
                        <div align="center" class="col-md-12 table-responsive">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                <tr>
                                    <th align="center">#</th>
                                    <th align="center">إسم العائلة</th>
                                    <th align="center">الإسم</th>
                                    <th align="center">الإسم الأول</th>
                                    <th align="center">الإسم الثاني</th>
                                    <th align="center">الإسم الثالث</th>
                                    <th align="center">الإسم الرابع</th>
                                    <th align="center">الجدول (أمة)</th>
                                    <th align="center">نوع الجدول</th>
                                    <th align="center">مرجع الداخلية</th>
                                    <th align="center">الرقم المدني</th>
                                    <th align="center">سنة الميلاد</th>
                                    <th align="center">المهنة</th>
                                    <th align="center">العنوان</th>
                                    <th align="center">حالة القيد</th>
                                    <th align="center">رقم القيد</th>
                                    <th align="center">تاريخ القيد</th>
                                    <th align="center">الدائرة</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td align="center"><?php echo e($data->id); ?></td>
                                        <td align="center"><?php echo e($data->family_name); ?></td>
                                        <td align="center"><?php echo e($data->name); ?></td>
                                        <td align="center"><?php echo e($data->first_name); ?></td>
                                        <td align="center"><?php echo e($data->second_name); ?></td>
                                        <td align="center"><?php echo e($data->third_name); ?></td>
                                        <td align="center"><?php echo e($data->forth_name); ?></td>
                                        <td align="center"><?php echo e($data->area->title); ?></td>
                                        <?php if($data->gender == 1): ?>
                                        <td align="center"> رجل</td>
                                        <?php else: ?>
                                            <td align="center"> انثى</td>
                                        <?php endif; ?>
                                        <td align="center"><?php echo e($data->internal_reference); ?></td>
                                        <td align="center"><?php echo e($data->civil_reference); ?></td>
                                        <td align="center"><?php echo e($data->birth_day); ?></td>
                                        <td align="center"><?php echo e($data->job); ?></td>
                                        <td align="center"><?php echo e($data->address); ?></td>
                                        <td align="center"><?php echo e($data->registration_status); ?></td>
                                        <td align="center"><?php echo e($data->registration_number); ?></td>
                                        <td align="center"><?php echo e($data->registration_data); ?></td>
                                        <td align="center"><?php echo e($data->circle->title); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th align="center">#</th>
                                    <th align="center">إسم العائلة</th>
                                    <th align="center">الإسم</th>
                                    <th align="center">الإسم الأول</th>
                                    <th align="center">الإسم الثاني</th>
                                    <th align="center">الإسم الثالث</th>
                                    <th align="center">الإسم الرابع</th>
                                    <th align="center">الجدول (أمة)</th>
                                    <th align="center">نوع الجدول</th>
                                    <th align="center">مرجع الداخلية</th>
                                    <th align="center">الرقم المدني</th>
                                    <th align="center">سنة الميلاد</th>
                                    <th align="center">المهنة</th>
                                    <th align="center">العنوان</th>
                                    <th align="center">حالة القيد</th>
                                    <th align="center">رقم القيد</th>
                                    <th align="center">تاريخ القيد</th>
                                    <th align="center">الدائرة</th>
                                </tr>
                                </tfoot>
                            </table>
                            <?php echo e($datas->links()); ?>

                        </div>
                    <?php else: ?>
                        <div align="center">لا يوجد بيانات للعرض</div>
                    <?php endif; ?>
                </div>
                <!-- /.box-body -->
            </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_style'); ?>
    <?php echo $__env->make('includes.admin.scripts_datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo JsValidator::formRequest('App\Http\Requests\Admin\Core_Data\Area\StatusEditRequest','#status'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuwait_elections\resources\views/admin/import/takeed/index.blade.php ENDPATH**/ ?>