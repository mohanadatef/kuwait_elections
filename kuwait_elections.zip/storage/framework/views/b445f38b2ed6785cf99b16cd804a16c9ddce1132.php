<?php $__env->startSection('title'); ?>
    قائمه المستخدم
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head_style'); ?>
    <?php echo $__env->make('includes.admin.header_datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            المستخدمين
            <small>كل المستخدمين</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> لوحه التحكم</a></li>
            <li><a href="<?php echo e(url('/admin/user/index')); ?>"><i class="fa fa-users"></i>قائمه المستخدمين</a></li>
        </ol>
    </section>
    <section class="content">
        <form method="get" action="<?php echo e(url('/admin/user/change_many_status')); ?>">
        <div class="box">
            <div class="box-header" align="right">
                <?php if (\Entrust::can('user-create')) : ?>
                <a href="<?php echo e(url('/admin/user/create')); ?>" class="btn btn-primary">اضافه</a>
                <?php endif; // Entrust::can ?>
                <?php if (\Entrust::can('user-many-status')) : ?>
                <input type="submit" value="تغير حاله" class="btn btn-primary">
                <?php endif; // Entrust::can ?>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <?php if(count($datas) > 0): ?>
                    <div align="center" class="col-md-12 table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <?php if (\Entrust::can('user-many-status')) : ?>
                        <th align="center">#</th>
                        <?php endif; // Entrust::can ?>
                        <th align="center">اسم المستخدم</th>
                        <th align="center">نوع المستخدم</th>
                        <th align="center">الرقم المدنى</th>
                        <th align="center">الدائرة</th>
                        <?php if (\Entrust::can('user-status')) : ?>
                        <th align="center">الحاله</th>
                        <?php endif; // Entrust::can ?>
                        <?php if (\Entrust::can('log-user-index')) : ?>
                        <th align="center">عرض السجل</th>
                        <?php endif; // Entrust::can ?>
                        <th align="center">التحكم</th>
                        <?php if (\Entrust::can('user-password')) : ?>
                        <th align="center">تعديل كلمه السر</th>
                        <?php endif; // Entrust::can ?>
                        <?php if (\Entrust::can('forgot-password')) : ?>
                        <th align="center">سجل تعديل كلمه السر</th>
                        <?php endif; // Entrust::can ?>
                        <?php if (\Entrust::can('user-upgrad')) : ?>
                        <th align="center">تغير نوع المستخدم</th>
                        <?php endif; // Entrust::can ?>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php if (\Entrust::can('user-many-status')) : ?>
                            <td align="center">
                                        <input type="checkbox" name="change_status[]"
                                               id="<?php echo e($data->id); ?>" value="<?php echo e($data->id); ?>">

                            </td>
                            <?php endif; // Entrust::can ?>
                            <td align="center"><?php echo e($data->name); ?></td>
                            <td align="center">
                                <?php $__currentLoopData = $data->role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    [<?php echo e($user_role->name); ?>],
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td align="center"><?php echo e($data->civil_reference); ?></td>
                            <td align="center"><?php echo e($data->circle->title); ?></td>
                            <?php if (\Entrust::can('user-status')) : ?>
                            <td align="center">
                                    <?php if($data->status ==1): ?>
                                        <a href="<?php echo e(url('/admin/user/change_status/'.$data->id)); ?>"><i
                                                    class="btn btn-danger ace-icon fa fa-close"> غير مفعل</i></a>
                                    <?php elseif($data->status ==0): ?>
                                        <a href="<?php echo e(url('/admin/user/change_status/'.$data->id)); ?>"><i
                                                    class="btn btn-primary ace-icon fa fa-check-circle"> مفعل</i></a>
                                    <?php endif; ?>
                            </td>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('log-user-index')) : ?>
                            <td align="center">
                                        <a href="<?php echo e(url('/admin/log/user/index/'.$data->id)); ?>"><i
                                                    class="btn btn-primary ace-icon fa fa-check-circle"> السجل</i></a>
                            </td>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('user-edit')) : ?>
                            <td align="center">
                                    <a href="<?php echo e(url('/admin/user/edit/'.$data->id)); ?>"><i
                                                class="btn btn-primary ace-icon fa fa-edit bigger-120  edit"
                                                data-id=""> تعديل</i></a>

                            </td>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('user-password')) : ?>
                            <td>
                                    <a href="<?php echo e(url('admin/user/change_password/'.$data->id)); ?>"
                                       class="btn btn-success"> تغير كلمه السر</a>
                            </td>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('forgot-password')) : ?>
                            <td>
                                <a href="<?php echo e(url('admin/forgot_password/index/'.$data->id)); ?>"
                                   class="btn btn-success"> سجل تعديل كلمه السر</a>
                            </td>
                            <?php endif; // Entrust::can ?>
                            <?php if (\Entrust::can('user-upgrad')) : ?>
                            <td>
                                <a href="<?php echo e(url('admin/user/upgrad/'.$data->id)); ?>"
                                   class="btn btn-success">تغير نوع المستخدم</a>
                            </td>
                            <?php endif; // Entrust::can ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                    <tr>
                        <?php if (\Entrust::can('user-many-status')) : ?>
                        <th align="center">#</th>
                        <?php endif; // Entrust::can ?>
                        <th align="center">اسم المستخدم</th>
                        <th align="center">نوع المستخدم</th>
                        <th align="center">الرقم المدنى</th>
                        <th align="center">الدائرة</th>
                        <?php if (\Entrust::can('user-status')) : ?>
                        <th align="center">الحاله</th>
                        <?php endif; // Entrust::can ?>
                        <?php if (\Entrust::can('log-user-index')) : ?>
                        <th align="center">عرض السجل</th>
                        <?php endif; // Entrust::can ?>
                        <th align="center">التحكم</th>
                        <?php if (\Entrust::can('user-password')) : ?>
                        <th align="center">تعديل كلمه السر</th>
                        <?php endif; // Entrust::can ?>
                        <?php if (\Entrust::can('forgot-password')) : ?>
                        <th align="center">سجل تعديل كلمه السر</th>
                        <?php endif; // Entrust::can ?>
                        <?php if (\Entrust::can('user-upgrad')) : ?>
                        <th align="center">تغير نوع المستخدم</th>
                        <?php endif; // Entrust::can ?>
                    </tr>
                    </tfoot>
                </table>
                    </div>
                <?php else: ?>
                    <div align="center">لا يوجد بيانات لعرضها</div>
                <?php endif; ?>
            </div>
            <!-- /.box-body -->
        </div>
        </form>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_style'); ?>
    <?php echo $__env->make('includes.admin.scripts_datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo JsValidator::formRequest('App\Http\Requests\Admin\ACL\User\StatusEditRequest','#status'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuwait_elections\resources\views/admin/acl/user/index.blade.php ENDPATH**/ ?>