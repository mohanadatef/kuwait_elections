<?php $__env->startSection('title'); ?>
    لوحه التحكم
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            لوحه التحكم
            <small>لوحه التحكم</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> لوحه التحكم</a></li>
        </ol>
    </section>
    <!-- Main content -->
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuwait_elections\resources\views/admin/admin.blade.php ENDPATH**/ ?>