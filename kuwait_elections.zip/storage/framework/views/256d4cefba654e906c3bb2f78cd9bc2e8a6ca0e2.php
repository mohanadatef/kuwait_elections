<?php $__env->startSection('title'); ?>
    قائمه السجل
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head_style'); ?>
    <?php echo $__env->make('includes.admin.header_datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            السجل
            <small>كل السجل</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> لوحه التحكم</a></li>
            <li><a href="<?php echo e(url('/admin/log/index')); ?>"><i class="fa fa-users"></i>قائمه السجل</a></li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <div class="box-header" align="right">
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <?php if(count($datas) > 0): ?>
                    <div align="center" class="col-md-12 table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th align="center">تاريخ / الوقت</th>
                        <th align="center">نوع الفعل</th>
                        <th align="center">وصف</th>
                        <th align="center">اسم المستخدم</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td align="center"><?php echo e($data->created_at); ?></td>
                            <td align="center"><?php echo e($data->action); ?></td>
                            <td align="center"><?php echo e($data->description); ?></td>
                            <td align="center"><?php echo e($data->user->username); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                    <tr>
                        <th align="center">تاريخ / الوقت</th>
                        <th align="center">نوع الفعل</th>
                        <th align="center">وصف</th>
                        <th align="center">اسم المستخدم</th>
                    </tr>
                    </tfoot>
                </table>
                    </div>
                <?php else: ?>
                    <div align="center">لا يوجد بيانات لعرضها</div>
                <?php endif; ?>
            </div>
            <!-- /.box-body -->
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_style'); ?>
    <?php echo $__env->make('includes.admin.scripts_datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuwait_elections\resources\views/admin/acl/log/index.blade.php ENDPATH**/ ?>