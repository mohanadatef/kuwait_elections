<?php $__env->startSection('title'); ?>
    تعديل منطقه
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            المناطق
            <small>تعديل منطقه</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i>لوحه التحكم</a></li>
            <li><a href="<?php echo e(url('/admin/area/index')); ?>"><i class="fa fa-permsissions"></i>المناطق</a></li>
            <li><a href="<?php echo e(url('/admin/area/edit/'.$data->id)); ?>"><i class="fa fa-permsission"></i>تعديل منطقه: <?php echo e($data->title); ?> </a></li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <div class="box-header">
                <h3>تعديل منطقه: <?php echo e($data->title); ?> </h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <form id="edit" action="<?php echo e(url('admin/area/update/'.$data->id)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('patch')); ?>

                    <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ""); ?>">
                        الاسم : <input type="text" value="<?php echo e($data->title); ?>"
                                         class="form-control" name="title" placeholder="برجاء ادخال الاسم">
                    </div>
                    <div class="form-group<?php echo e($errors->has('order') ? ' has-error' : ""); ?>">
                        الترتيب : <input type="text" value="<?php echo e($data->order); ?>"
                                         class="form-control" name="order" placeholder="برجاء ادخال الترتيب">
                    </div>
                    <div align="center">
                        <input type="submit" class="btn btn-primary" value="تعديل">
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_style'); ?>
    <?php echo JsValidator::formRequest('App\Http\Requests\Admin\Core_Data\Area\EditRequest','#edit'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuwait_elections\resources\views/admin/core_data/area/edit.blade.php ENDPATH**/ ?>