<?php $__env->startSection('title'); ?>
    اضافه منطقه
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Area
            <small>Create Area</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i>لوحه التحكم</a></li>
            <li><a href="<?php echo e(url('/admin/area/index')); ?>"><i class="fa fa-permsissions"></i>منطقه</a></li>
            <li><a href="<?php echo e(url('/admin/area/create')); ?>"><i class="fa fa-permsission"></i>اضافه منطقه</a>
            </li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <div class="box-header">
                <h3>اضافه منطقه</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <form id='create' action="<?php echo e(url('admin/area/store')); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ""); ?>">
                        الاسم : <input type="text" value="<?php echo e(Request::old('title')); ?>"
                                       class="form-control" name="title" placeholder="برجاء ادخال منطقه">
                    </div>
                    <div class="form-group<?php echo e($errors->has('order') ? ' has-error' : ""); ?>">
                        الترتيب : <input type="number" value="<?php echo e(Request::old('order')); ?>"
                                       class="form-control" name="order" placeholder="برجاء ادخال الترتيب">
                    </div>
                    <div align="center">
                        <input type="submit" class="btn btn-primary" value="اضافه">
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_style'); ?>
    <?php echo JsValidator::formRequest('App\Http\Requests\Admin\Core_Data\Area\CreateRequest','#create'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuwait_elections\resources\views/admin/core_data/area/create.blade.php ENDPATH**/ ?>