<h1>Hi, </h1>
l<p>Sending Mail from Laravel.</p><?php /**PATH C:\xampp\htdocs\kuwait_elections\resources\views/mail.blade.php ENDPATH**/ ?>