<?php $__env->startSection('title'); ?>
    ناخبين
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            ناخبين
            <small>ناخبين</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i>لوحه التحكم</a></li>
            <li><a href="<?php echo e(url('/admin/takeed/import/form')); ?>"><i class="fa fa-permsissions"></i>ناخبين</a></li>
            </li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <div class="box-header">
                <h3>اضافه ناخبين</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <form id='create' action="<?php echo e(url('admin/takeed/import')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group<?php echo e($errors->has('file') ? ' has-error' : ""); ?>">
                        <table class="table">
                            <tr>
                                <td width="40%" align="right"><label>برجاء تحميل</label></td>
                                <td width="30"><input type="file" multiple='multiple' value="<?php echo e(Request::old('file')); ?>" name="file[]"/></td>
                            </tr>
                            <tr>
                                <td width="40%" align="right"></td>
                                <td width="30"><span class="text-muted"></span></td>
                            </tr>
                        </table>
                    </div>
                    <div align="center">
                        <input type="submit" class="btn btn-primary" value="رفع">
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_style'); ?>
    <?php echo JsValidator::formRequest('App\Http\Requests\Admin\Core_Data\Area\CreateRequest','#create'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuwait_elections\resources\views/admin/import/takeed/form.blade.php ENDPATH**/ ?>