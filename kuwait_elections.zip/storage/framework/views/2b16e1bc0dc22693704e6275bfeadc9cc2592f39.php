<?php $__env->startSection('title'); ?>
    اضافه نوع المستخدم
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head_style'); ?>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/css/admin/multi-select.css')); ?>">
    <style>
        .ms-container {
            width: 25%;
        }
        li.ms-elem-selectable, .ms-selected {
            padding: 5px !important;
        }
        .ms-list {
            height: 150px !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            نوع المستخدم
            <small>اضافه نوع المستخدم</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> لوحه التحكم</a></li>
            <li><a href="<?php echo e(url('/admin/role/index')); ?>"><i class="fa fa-roles"></i>قائمه نوع المستخدم</a></li>
            <li><a href="<?php echo e(url('Admin')); ?>"><i class="fa fa-role"></i>اضافه نوع المستخدم</a></li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <div class="box-header">
                <h3>اضافه نوع المستخدم</h3>
            </div>
            <div class="box-body">
                <form id='create' action="<?php echo e(url('admin/role/store')); ?>"  method="POST">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ""); ?>">
                        الاسم : <input type="text" value="<?php echo e(Request::old('name')); ?>" class="form-control" name="name"
                                      placeholder="برجاء ادخال الاسم">
                    </div>
                    <div class="form-group<?php echo e($errors->has('display_name') ? ' has-error' : ""); ?>">
                        اسم العرض : <input type="text" value="<?php echo e(Request::old('display_name')); ?>" class="form-control"
                                              name="display_name" placeholder="برجاء ادخال اسم العرض">
                    </div>
                    <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ""); ?>">
                        الوصف : <textarea type="text"  class="form-control" placeholder="برجاء ادخال الوصف" name="description"><?php echo e(Request::old('description')); ?></textarea>
                    </div>
                    <div class="form-group<?php echo e($errors->has('permission_id') ? ' has-error' : ""); ?>">
                         اختيار الاذنات :
                        <select id="permission" multiple='multiple' class="form-control"  name="permission[]">
                            <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mypermission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($mypermission->id); ?>"> <?php echo e($mypermission->display_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div align="center">
                        <input type="submit" class="btn btn-primary" value="اضافه">
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_style'); ?>
    <script src="<?php echo e(url('public/js/admin/jquery.multi-select.js')); ?>"></script>
    <script type="text/javascript">
        $('#permission').multiSelect();
    </script>
    <?php echo JsValidator::formRequest('App\Http\Requests\Admin\ACL\Role\CreateRequest','#create'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuwait_elections\resources\views/admin/acl/role/create.blade.php ENDPATH**/ ?>