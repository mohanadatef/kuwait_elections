<?php

namespace App\Interfaces\ACL;


interface ForgotPasswordInterface{

    public function Get_All_Data($id);

}