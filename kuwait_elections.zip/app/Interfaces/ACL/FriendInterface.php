<?php

namespace App\Interfaces\ACL;


interface FriendInterface{

    public function Get_All_Request_Data();
    public function Get_All_Friend_Data();

}