<?php

namespace App\Interfaces\Social_Media;


interface LikeInterface{

    public function Get_All_Datas_Like($id,$category);
    public function Get_All_Datas();
}