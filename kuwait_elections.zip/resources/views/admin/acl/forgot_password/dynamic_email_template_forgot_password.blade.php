<p>{{$data['name']}}</p>
<p>{{$data['message']}}</p>