<!DOCTYPE html>
<html>
<head>
    @include('includes.admin.head')
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
    @include('includes.admin.header')
    @include('includes.admin.main-sidebar')
    <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <!-- Main content -->
            <section class="content">
                <h1>لا يمكنك الدخول للصفحه لان غير مصرح لك برجاء الاتصال بالدعم الفنى</h1>
            </section>
            <!-- /.content -->
        </div>
    @include('includes.admin.footer')
</div>
<!-- ./wrapper -->
@include('includes.admin.script')
</body>
</html>
