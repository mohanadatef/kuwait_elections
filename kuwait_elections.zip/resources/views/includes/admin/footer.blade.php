<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>نسخه</b> 1.0.0
    </div>
    <strong>حقوق النشر &copy; 2020 <a href="#"> </a>.</strong> كلها محفوظه .
</footer>
@yield('footer')